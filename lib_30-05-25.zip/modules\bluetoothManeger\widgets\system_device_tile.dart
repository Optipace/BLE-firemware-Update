import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:tracker_firmware/Const_TermAndFunction/constants.dart';

class SystemDeviceTile extends StatefulWidget {
  final BluetoothDevice device;
  final VoidCallback onOpen;
  final VoidCallback onConnect;

  const SystemDeviceTile({
    required this.device,
    required this.onOpen,
    required this.onConnect,
    super.key,
  });

  @override
  State<SystemDeviceTile> createState() => _SystemDeviceTileState();
}

class _SystemDeviceTileState extends State<SystemDeviceTile> {
  BluetoothConnectionState _connectionState = BluetoothConnectionState.disconnected;

  late StreamSubscription<BluetoothConnectionState> _connectionStateSubscription;

  @override
  void initState() {
    super.initState();

    _connectionStateSubscription = widget.device.connectionState.listen((state) {
      _connectionState = state;
      if (mounted) {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _connectionStateSubscription.cancel();
    super.dispose();
  }

  bool get isConnected {
    return _connectionState == BluetoothConnectionState.connected;
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        widget.device.platformName,
        style: TextStyle(color: darkBg, fontFamily: baseFont, fontWeight: FontWeight.w500, fontSize: 18),
      ),
      subtitle: Text(
        widget.device.remoteId.str,
        style: TextStyle(
            color: darkBg.withOpacity(0.8), fontFamily: baseFont, fontWeight: FontWeight.w300, fontSize: 16),
      ),
      trailing: ElevatedButton(
        style: ButtonStyle(
          backgroundColor: MaterialStatePropertyAll(darkBg.withOpacity(0.8)),
        ),
        onPressed: isConnected ? widget.onOpen : widget.onConnect,
        child: isConnected
            ? Text(
                'OPEN',
                style: TextStyle(
                    color: lightBg, fontFamily: baseFont, fontSize: 18, fontWeight: FontWeight.w500),
              )
            : Text(
                'CONNECT',
                style: TextStyle(
                    color: lightBg, fontFamily: baseFont, fontSize: 18, fontWeight: FontWeight.w500),
              ),
      ),
    );
  }
}
