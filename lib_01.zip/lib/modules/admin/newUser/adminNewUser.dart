// import 'dart:html';

// import 'dart:html';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tracker_firmware/modules/admin/admin_main.dart';

import '../../../widgets/buttons.dart';
import '../../../widgets/constants.dart';
import '../../../widgets/textFields.dart';

class AdminNewUser extends StatefulWidget{
  @override
  State<AdminNewUser> createState() => AdminNewUserState();

}
class AdminNewUserState extends State<AdminNewUser>{

  bool validateUser = false;

  TextEditingController _name = TextEditingController();
  TextEditingController _empRegId = TextEditingController();
  TextEditingController _email = TextEditingController();
  TextEditingController _contact = TextEditingController();
  TextEditingController _password = TextEditingController();
  TextEditingController _repassword = TextEditingController();
  TextEditingController _createdBy = TextEditingController();
  TextEditingController _modifiedBy = TextEditingController();
  TextEditingController _designationId = TextEditingController();
  TextEditingController _deviceId = TextEditingController();



  @override
  Widget build(BuildContext context) {
    bool _showError = false;
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("New-User",style: TextStyle(fontFamily: baseFont,fontWeight: FontWeight.w800, fontSize: 22,color: lightBg),),
        toolbarHeight: 60,
        backgroundColor: darkBg,
        elevation: 5,
        shadowColor: darkBg,
      ),
      backgroundColor: lightBg,
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: EdgeInsets.only(top: 15),
                child: Center(
                  child: Text("ENTER THE DETAILS",
                    style: TextStyle(
                        fontFamily: baseFont,
                        fontWeight: FontWeight.w800,
                        fontSize: 24,
                        color: darkBg,
                        shadows: [Shadow(
                          color: Colors.black,
                          blurRadius: 0.5,
                          offset: Offset(0.5, 0.5)
                        )]
                    ),
                  ),
                ),
              ),
              Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                // mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20 ,),
                  //----Name-----
                  LabelText(text: "Emoplyee Name :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                      hintText: "Enter Empolyee name",
                      Controller: _name,
                      onChanged: (value){},
                      enable: true,
                      etext: validateUser && _name.text.trim().isEmpty ?"Please Enter the name" : "",
                  ),
                  SizedBox(height: 15,),

                  //----empRegId------
                  LabelText(text: "Emoplyee Regestred ID[Company ID]:"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                      hintText: "Enter empRegID",
                      Controller: _empRegId,
                      onChanged: (value){},
                      enable: true,
                      etext: validateUser && _empRegId.text.trim().isEmpty ?"Please Enter the empRegID" : "",
                  ),
                  SizedBox(height: 15,),

                  //------email------
                  LabelText(text: "Empolyee E-Mail :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                      hintText: "Enter Empolyee E-Mail",
                      Controller: _email,
                      onChanged: (value){},
                      enable: true,
                      etext: validateUser && _email.text.trim().isEmpty ?"Please Enter the E-Mail" : "",
                  ),
                  SizedBox(height: 15,),

                  //-----Contact ------
                  LabelText(text: "Empolyee Phone number :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                      hintText: "Enter Empolyee Phone number",
                      Controller: _contact,
                      onChanged: (value){},
                      enable: true,
                      etext: validateUser && _contact.text.trim().isEmpty ?"Please Enter the Phone Number" : "",
                  ),
                  SizedBox(height: 15,),

                  //----DesignationID---- [DROPDOWN]
                  LabelText(text: "Empolyee DesignationID :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                      hintText: "Enter Empolyee Designation ID",
                      Controller: _designationId,
                      onChanged: (value){},
                      enable: true,
                      etext: validateUser && _designationId.text.trim().isEmpty ?"Please Enter the Designation ID" : "",
                  ),
                  SizedBox(height: 15,),

                  //-----password-----
                  LabelText(text: "Empolyee Password :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                    hintText: "Enter Empolyee Password",
                    Controller: _password,
                    onChanged: (value){},
                    enable: true,
                    etext: validateUser && _password.text.trim().isEmpty ?"Please Enter the Password" : "",
                  ),
                  SizedBox(height: 15,),

                  //-----password-----
                  LabelText(text: "Re-Enter Empolyee Password :"),
                  SizedBox(height: 8,),
                  TextFeildNewUser(
                    hintText: "Re-Enter Empolyee Password",
                    Controller: _repassword,
                    onChanged: (value){},
                    enable: true,
                    etext: validateUser && _password.text.trim().isEmpty ?"Please Enter the Password" : "",
                  ),
                  SizedBox(height: 15,),


                ],
              )
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 20),
                child: manageUserBtn(
                    text: "ADD USER",
                    onPress: (){
                      ValidateUser();
                      print("validate User : $validateUser");
                      if(!validateUser || true){
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content:Row(
                                children: [
                                  Icon(CupertinoIcons.checkmark_seal_fill,color: lightBg,),
                                  SizedBox(width: 15,),
                                  Text('User Added Successfully!!',
                                    style: TextStyle(
                                      color: lightBg,
                                      fontWeight: FontWeight.w300,
                                      fontFamily: baseFont,
                                      fontSize: 22,

                                    ),),
                                ],
                              ),
                              behavior: SnackBarBehavior.floating,
                              backgroundColor: darkBg,
                              elevation: 5,
                            margin: EdgeInsets.all(16),
                            duration: Duration(seconds: 3),


                          ),
                        );
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminMain()));

                      }
                    }
                ),
              )
            ],
          ),
        )
      ),
    );
  }

  void ValidateUser(){
    final Controllers = [
      _name,
      _empRegId,
      _email,
      _contact,
      _password,
      _createdBy,
      _modifiedBy,
      _designationId,
    ];

    for(var controller in Controllers){
      if(controller.text.trim().isEmpty){
        setState(() {
          validateUser =true;
        });
      }
    }
    Future.delayed(Duration(seconds: 3),(){
      setState(() {
        validateUser = false;
      });
    });
  }
}