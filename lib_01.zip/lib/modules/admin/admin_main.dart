import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tracker_firmware/modules/admin/api/api.dart';
import 'package:tracker_firmware/modules/admin/editUser/adminEditUser.dart';
import 'package:tracker_firmware/modules/admin/log/admin_logs.dart';
import 'package:tracker_firmware/modules/admin/newUser/adminNewUser.dart';
import 'package:tracker_firmware/widgets/splash_screen.dart';

import '../../widgets/buttons.dart';
import '../../widgets/constants.dart';

class AdminMain extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      // resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          Container(color: lightBg,),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 360,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: darkBg,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(300),
                  bottomRight: Radius.circular(300),
                ),
                border: Border.all(
                  color: Colors.black,
                  width: 0.5
                ),
                boxShadow: [
                  BoxShadow(
                    color: darkBg,
                    blurRadius: 30,
                  )
                ]
              ),
            ),
          ),
          Positioned(
            left: MediaQuery.of(context).size.width/4,
            top: 160,
            child: Container(
              child: Column(
                children: [
                  Text("ADMIN",
                    style: TextStyle(
                        fontSize: 38,
                        color: lightBg,
                        fontFamily:baseFont,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                        backgroundColor: darkBg,
                        shadows: [Shadow(
                          blurRadius: 2,

                        )],

                    ),
                  ),
                  Text("DASH-BOARD",
                    style: TextStyle(
                        color: lightBg,
                        fontSize: 38,
                        fontFamily: baseFont,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.1,
                      backgroundColor: darkBg,
                      shadows: [Shadow(
                          blurRadius: 2,
                      )],

                    ),
                  ),
                ],
              )
            )
          ),
          Align(
            alignment:Alignment.center,
            child: Padding(
              padding: const EdgeInsets.only(top: 250),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AdminMainBtn(
                      icon: Image.asset('assets/image/viewLog.png',width: 24,height: 24,color: darkBg,),
                      text: "View Log",
                      onpress: (){
                        Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) => AdminLogs()));
                      }
                  ),
                  SizedBox(height: 25,),
                  AdminMainBtn(
                      icon: Image.asset('assets/image/user.png',width: 24,height: 24,color: darkBg,),
                      text: "New User",
                      onpress: (){
                        Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) => AdminNewUser()));
                      }
                  ),
                  SizedBox(height: 25,),
                  AdminMainBtn(
                      icon: Image.asset('assets/image/editUser.png',width: 24,height: 24,color: darkBg,),
                      text: "Modify User",
                      onpress: (){
                        Navigator.of(context).push(
                            MaterialPageRoute<void>(
                                builder: (_) => AdminEditUser()));
                      }
                  ),
                  SizedBox(height: 25 ,),
                  SizedBox(
                    width: 350,
                    height: 60,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (_) => splashScreen()));
                      },
                      style: ElevatedButton.styleFrom(
                          backgroundColor: darkBg,
                          elevation: 8,
                          shadowColor: darkBg,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(25),
                              side: BorderSide(
                                  color: Colors.black,
                                  width: 0.5
                              )
                          )
                      ),
                      child: Text("LOGOUT",
                        style: TextStyle(
                            fontFamily: baseFont,
                            fontSize: 22,
                            letterSpacing: 1.5,
                            fontWeight: FontWeight.w800,
                            shadows: [Shadow(
                                color: Colors.black,
                                blurRadius: 0.1
                            )]
                        ),
                      ),
                    ),
                  ),


                ],
              ),
            )
          ),

        ],
      )
    );
  }

}