
import 'dart:ui';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// Dark background
Color darkBg = Color(0xFF358A94);
// Color.fromRGBO(58, 80, 153, 1.0);

// Light background
Color lightBg = Color.fromRGBO(234, 241, 251, 1.0);

// buttonColor
Color primaryButton = Color.fromRGBO(53, 138, 148, 1.0);
Color primaryButtonText = Colors.white;

// primary Text
Color primaryText = Color.fromRGBO(44, 62, 80, 1.0);
Color secondaryText = Color.fromRGBO(108, 122, 137, 1.0);

//Border Or Icon
Color outlineColor = Color.fromRGBO(162, 195, 200, 1.0);

String baseFont = 'Crimson';

bool isSession = false;





